@props(['value','htmlFor'])



<label for={{$htmlFor}} class="text-gray-800" >{{$value}}</label>